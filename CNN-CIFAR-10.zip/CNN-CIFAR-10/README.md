# tensorflow-CNN-CIFAR-10
该程序是基于tensorflow来实现CNN，并通过CIFAR-10数据集训练该神经网络。
其中
cifar10-main.py---包含了构建和验证神经网络的代码
cifar10-rescover.py---包含了从保存的检查点中恢复先前训练好的神经网络的代码
cifar10.py；download.py；dataset.py；cache.py---一些辅助代码

具体的实现方法可以参考我写的教程：
http://blog.csdn.net/x_lock?viewmode=contents
